var config = {
  OPENWEATHER_API_KEY : 'bbb2feb3c9b2a6ae9ee156d7853022ea',
  LASTFM_API_KEY : 'f73ac4f7b854a7ccb8e57db3d99200a6',
}